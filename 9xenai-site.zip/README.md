# 9xenai website: SEO + GEO build

## Folders
- `dist/`    Deploy this folder to your web root. 16 prerendered pages on clean URLs
             (/, /services/, /services/automation/, ...), plus sitemap.xml, robots.txt,
             llms.txt, llms-full.txt and og-image.png.
- `source/`  `9xenai.html` is the editable single-file site. `build.js` regenerates `dist/` from it.

## Rebuild after any edit
    npm i playwright && npx playwright install chromium
    node source/build.js --src source/9xenai.html --out dist --site https://YOURDOMAIN.com

`--site` sets the canonical, sitemap, JSON-LD and Open Graph URLs. It defaults to https://9xenai.com,
which is an assumption: pass your real domain.

## What is automatic
At runtime (every route and every language change) the page rewrites: title, meta description,
canonical, 8 hreflang alternates + x-default, og:url / og:locale / og:image, Twitter card,
a JSON-LD graph (Organization, WebSite, WebPage/AboutPage/ContactPage/CollectionPage, BreadcrumbList,
per-service FAQPage, speakable), and an "At a glance" fact block on the home page built from the
FAQ and service data. First-time visitors get their browser language; `?lang=bn` etc. forces one.
The build adds crawlable HTML for every route, so crawlers that do not run JavaScript still see content.

## Hosting notes
- Serve /foo/ from /foo/index.html (default on Netlify, Vercel, Cloudflare Pages, GitHub Pages, nginx with index).
- Upload `source/9xenai.html` alone and it still works (hash routes), but search engines ignore `#` routes,
  so use `dist/` for SEO.
- After deploying: submit https://YOURDOMAIN.com/sitemap.xml in Google Search Console and Bing Webmaster Tools.
- Not included on purpose: business address, phone, email, social profiles, reviews. Add them to the
  Organization JSON-LD in the head only when real, as invented details hurt rather than help.
