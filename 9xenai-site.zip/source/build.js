#!/usr/bin/env node
/**
 * 9xenai SEO + GEO build
 *   node build.js [--src 9xenai.html] [--out dist] [--site https://9xenai.com]
 *
 * Output (deploy the whole folder to the web root):
 *   index.html, services/index.html, services/<id>/index.html, ...   prerendered, crawlable pages
 *   sitemap.xml  robots.txt  llms.txt  llms-full.txt  og-image.png
 * Requires:  npm i playwright   (and a Chromium: npx playwright install chromium)
 */
const fs = require('fs'), path = require('path');
const { chromium } = require('playwright');

const arg = (k, d) => { const i = process.argv.indexOf('--' + k); return i > 0 ? process.argv[i + 1] : d; };
const SRC = path.resolve(arg('src', '9xenai.html'));
const OUT = path.resolve(arg('out', 'dist'));
const SITE = arg('site', 'https://9xenai.com').replace(/\/+$/, '');
const TODAY = new Date().toISOString().slice(0, 10);
const PAGES = ['home', 'services', 'industries', 'approach', 'trust', 'products', 'contact', 'about', 'cases', 'insights'];

const routePath = h => h === 'home' ? '' : h.startsWith('service-') ? 'services/' + h.slice(8) + '/' : h + '/';
const urlOf = h => SITE + '/' + routePath(h);
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

(async () => {
  fs.rmSync(OUT, { recursive: true, force: true });
  fs.mkdirSync(OUT, { recursive: true });

  // 1. build-mode source: clean URLs on, real domain injected
  let html = fs.readFileSync(SRC, 'utf8').split('https://9xenai.com').join(SITE);
  html = html.replace('<meta name="author" content="9xenai">',
    `<meta name="author" content="9xenai">\n<meta name="9x-site" content="${SITE}">\n<meta name="9x-clean" content="1">\n<meta name="9x-modified" content="${TODAY}">`);
  const tmp = path.join(OUT, '_build.html');
  fs.writeFileSync(tmp, html);

  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1366, height: 900 }, reducedMotion: 'reduce' });
  const probe = await ctx.newPage();
  await probe.goto('file://' + tmp + '#home');
  await probe.waitForTimeout(500);
  const data = await probe.evaluate(() => ({
    order: Array.from(document.querySelectorAll('#menuSvc a')).map(a => a.getAttribute('href').split('/').filter(Boolean).pop().replace('#service-', '')),
  }));
  await probe.close();

  // The page keeps its data inside a closure, so read it back from the rendered service pages.
  const routes = PAGES.slice();
  const services = [];
  for (const id of data.order) { routes.push('service-' + id); services.push(id); }

  const facts = { desc: {}, svc: {}, faq: [] };

  // 2. prerender every route
  for (const h of routes) {
    const p = await ctx.newPage();
    const errs = [];
    p.on('pageerror', e => errs.push(e.message));
    await p.goto('file://' + tmp + '#' + h);
    await p.waitForTimeout(700);
    await p.evaluate(() => { document.querySelectorAll('.page.on [data-fx]').forEach(e => e.classList.add('fx-in')); });
    // collect text for llms files
    facts.desc[h] = await p.evaluate(() => ({
      title: document.title,
      desc: (document.querySelector('meta[name="description"]') || {}).content || '',
      h1: (document.querySelector('.page.on h1') || {}).textContent || '',
      text: (document.querySelector('.page.on') || {}).innerText || '',
    }));
    if (h === 'home') facts.faq = await p.evaluate(() => Array.from(document.querySelectorAll('#faqList details')).map(d => [d.querySelector('summary').textContent.trim(), d.innerText.replace(d.querySelector('summary').innerText, '').trim()]));

    // strip runtime-only state so the file boots cleanly in a browser
    await p.evaluate(() => {
      document.querySelectorAll('.rv,.fx-r').forEach(e => e.classList.remove('rv', 'in', 'fx-r', 'fx-in'));
      document.querySelectorAll('[data-rv],[data-fx]').forEach(e => { e.removeAttribute('data-rv'); e.removeAttribute('data-fx'); });
      document.querySelectorAll('.fx-aura,.fx-top,.fx-stk,.tg9').forEach(e => e.remove());
      document.querySelectorAll('[style]').forEach(e => {
        ['--cx', '--cy', '--rx', '--ry', '--bx', '--by', '--px', '--py', '--d'].forEach(k => e.style.removeProperty(k));
        if (!e.getAttribute('style')) e.removeAttribute('style');
      });
      const de = document.documentElement;
      de.classList.remove('fx', 'fx-hov', 'on-contact'); de.removeAttribute('data-theme');
      const hd = document.querySelector('header'); if (hd) hd.classList.remove('stuck');
      document.querySelectorAll('#feed li').forEach((e, i) => { if (i > 5) e.remove(); });
    });
    let out = await p.content();
    out = out.replace(/<script id="_build"[\s\S]*?<\/script>/, '');
    const dir = path.join(OUT, routePath(h));
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, 'index.html'), out);
    if (errs.length) console.warn('  ! errors on', h, errs.slice(0, 2));
    await p.close();
    process.stdout.write('  prerendered /' + routePath(h) + '\n');
  }
  fs.unlinkSync(tmp);

  // 3. sitemap.xml
  const prio = h => h === 'home' ? '1.0' : h.startsWith('service-') || ['services', 'contact'].includes(h) ? '0.9' : '0.7';
  fs.writeFileSync(path.join(OUT, 'sitemap.xml'),
    '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' +
    routes.map(h => `  <url><loc>${urlOf(h)}</loc><lastmod>${TODAY}</lastmod><changefreq>${h === 'home' ? 'weekly' : 'monthly'}</changefreq><priority>${prio(h)}</priority></url>`).join('\n') +
    '\n</urlset>\n');

  // 4. robots.txt (search + AI/answer-engine crawlers are explicitly welcome)
  const bots = ['Googlebot', 'Bingbot', 'GPTBot', 'OAI-SearchBot', 'ChatGPT-User', 'ClaudeBot', 'Claude-SearchBot', 'Claude-User', 'PerplexityBot', 'Perplexity-User', 'Google-Extended', 'Applebot-Extended', 'CCBot', 'Amazonbot', 'DuckAssistBot', 'meta-externalagent'];
  fs.writeFileSync(path.join(OUT, 'robots.txt'),
    '# Generated by build.js\nUser-agent: *\nAllow: /\n\n' + bots.map(b => `User-agent: ${b}\nAllow: /\n`).join('\n') +
    `\nSitemap: ${SITE}/sitemap.xml\n`);

  // 5. llms.txt + llms-full.txt (GEO)
  const clean = t => t.replace(/\n{3,}/g, '\n\n').replace(/[ \t]+\n/g, '\n').trim();
  const home = facts.desc.home;
  const svcLine = id => `- [${facts.desc['service-' + id].h1 || id}](${urlOf('service-' + id)}): ${facts.desc['service-' + id].desc}`;
  const company = ['about', 'approach', 'trust', 'products', 'industries', 'cases', 'insights', 'contact'];
  const summary = '9xenai is an AI consulting, automation and software company. It designs, builds and operates AI for organisations in Bangladesh and international markets, starting from a measurable business case. Delivery is in Bangla and English.';
  fs.writeFileSync(path.join(OUT, 'llms.txt'),
    `# 9xenai\n\n> ${summary}\n\n## Services\n\n${services.map(svcLine).join('\n')}\n\n## Company\n\n` +
    company.map(h => `- [${facts.desc[h].h1 || h}](${urlOf(h)}): ${facts.desc[h].desc}`).join('\n') +
    `\n\n## Frequently asked questions\n\n` + facts.faq.map(([q, a]) => `**${q}** ${a}`).join('\n\n') +
    `\n\n## Optional\n\n- [Full text of this site](${SITE}/llms-full.txt)\n- [Sitemap](${SITE}/sitemap.xml)\n`);
  fs.writeFileSync(path.join(OUT, 'llms-full.txt'),
    `# 9xenai: full site text\n\n> ${summary}\n\nFigures on case studies and service pages are illustrative planning targets, not guarantees.\n\n` +
    routes.map(h => `---\n\n## ${facts.desc[h].title}\n\nURL: ${urlOf(h)}\n\n${clean(facts.desc[h].text)}\n`).join('\n'));

  // 6. social card
  const card = await ctx.newPage();
  await card.setViewportSize({ width: 1200, height: 630 });
  await card.setContent(`<body style="margin:0;width:1200px;height:630px;background:radial-gradient(900px 500px at 15% 10%,#0e7a5a 0%,transparent 60%),radial-gradient(800px 500px at 100% 100%,#223fb8 0%,transparent 60%),#06141F;color:#EAF4F0;font-family:Georgia,'DejaVu Serif',serif;display:flex;flex-direction:column;justify-content:center;padding:0 84px;box-sizing:border-box">
    <div style="font:600 34px/1 Georgia,serif;letter-spacing:.01em;color:#5CF2C0;margin-bottom:34px">9xenai</div>
    <div style="font-size:78px;line-height:1.08;font-weight:600;max-width:980px">Multiply what your teams can do with <i style="color:#5CF2C0">automation</i>.</div>
    <div style="font:400 30px/1.4 system-ui,sans-serif;color:#9fb8c4;margin-top:36px">Enterprise AI consulting, automation and software. Bangladesh and international markets.</div></body>`);
  await card.screenshot({ path: path.join(OUT, 'og-image.png') });

  await browser.close();
  console.log(`\nDone. ${routes.length} pages + sitemap.xml, robots.txt, llms.txt, llms-full.txt, og-image.png -> ${OUT}`);
})().catch(e => { console.error(e); process.exit(1); });
